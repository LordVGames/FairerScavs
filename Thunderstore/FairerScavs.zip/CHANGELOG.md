## 1.0.1

- Update dependencies

## 1.0.0

- First release